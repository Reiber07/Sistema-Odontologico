import java.util.ArrayList;

public class Paciente extends Persona {
    private ArrayList<Cita> historialCitas;

    public Paciente(String nombre, String identificacion, String telefono, String email) {
        super(nombre, identificacion, telefono, email);
        this.historialCitas = new ArrayList<>();
    }

    public void agregarCita(Cita cita) {
        historialCitas.add(cita);
    }

    public ArrayList<Cita> getHistorialCitas() {
        return historialCitas;
    }

    public void mostrarHistorial() {
        if (historialCitas.isEmpty()) {
            System.out.println("  Sin citas registradas.");
        } else {
            for (Cita c : historialCitas) {
                System.out.println("  " + c.mostrarInfo());
            }
        }
    }
}