import java.util.ArrayList;

public class Profesional extends Persona {
    private String especialidad;
    private ArrayList<Cita> citasAsignadas;

    public Profesional(String nombre, String identificacion, String telefono, String email, String especialidad) {
        super(nombre, identificacion, telefono, email);
        this.especialidad = especialidad;
        this.citasAsignadas = new ArrayList<>();
    }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public ArrayList<Cita> getCitasAsignadas() { return citasAsignadas; }

    public void agregarCita(Cita cita) {
        citasAsignadas.add(cita);
    }

    public boolean estaDisponible(String fecha, String horario) {
        for (Cita c : citasAsignadas) {
            if (c.getFecha().equals(fecha) && c.getHorario().equals(horario)
                    && !c.isCancelada()) {
                return false;
            }
        }
        return true;
    }

    public String mostrarInfo() {
        return super.mostrarInfo() + " | Especialidad: " + especialidad;
    }
}