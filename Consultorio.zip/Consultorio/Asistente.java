import java.util.ArrayList;

public class Asistente extends Persona {
    private Profesional profesionalAsignado;
    private ArrayList<Cita> citasAtendidas;

    public Asistente(String nombre, String identificacion, String telefono, String email) {
        super(nombre, identificacion, telefono, email);
        this.citasAtendidas = new ArrayList<>();
        this.profesionalAsignado = null;
    }

    public Profesional getProfesionalAsignado() { return profesionalAsignado; }
    public void setProfesionalAsignado(Profesional profesional) { this.profesionalAsignado = profesional; }

    public ArrayList<Cita> getCitasAtendidas() { return citasAtendidas; }

    public void agregarCita(Cita cita) {
        citasAtendidas.add(cita);
    }

    public boolean estaDisponible(String fecha, String horario) {
        for (Cita c : citasAtendidas) {
            if (c.getFecha().equals(fecha) && c.getHorario().equals(horario)
                    && !c.isCancelada()) {
                return false;
            }
        }
        return true;
    }

    public String mostrarInfo() {
        String prof = (profesionalAsignado != null) ? profesionalAsignado.getNombre() : "Sin asignar";
        return super.mostrarInfo() + " | Apoya a: " + prof;
    }
}