import java.util.ArrayList;

public class Consultorio {
    private int numero;
    private String descripcion;
    private ArrayList<Cita> citas;

    public Consultorio(int numero, String descripcion) {
        this.numero = numero;
        this.descripcion = descripcion;
        this.citas = new ArrayList<>();
    }

    public int getNumero() { return numero; }
    public String getDescripcion() { return descripcion; }
    public ArrayList<Cita> getCitas() { return citas; }

    public boolean estaDisponible(String fecha, String horario) {
        for (Cita c : citas) {
            if (c.getFecha().equals(fecha) && c.getHorario().equals(horario)
                    && !c.isCancelada()) {
                return false;
            }
        }
        return true;
    }

    public boolean asignarCita(Cita cita) {
        if (estaDisponible(cita.getFecha(), cita.getHorario())) {
            citas.add(cita);
            return true;
        }
        System.out.println("Consultorio " + numero + " no disponible en " + cita.getFecha() + " " + cita.getHorario());
        return false;
    }

    public String mostrarInfo() {
        return "Consultorio #" + numero + " - " + descripcion;
    }
}