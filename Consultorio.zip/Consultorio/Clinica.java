import java.util.ArrayList;

public class Clinica {
    private String nombre;
    private ArrayList<Consultorio> consultorios;
    private ArrayList<Profesional> profesionales;
    private ArrayList<Asistente> asistentes;
    private ArrayList<Paciente> pacientes;
    private ArrayList<Cita> citas;

    public Clinica(String nombre) {
        this.nombre = nombre;
        this.consultorios = new ArrayList<>();
        this.profesionales = new ArrayList<>();
        this.asistentes = new ArrayList<>();
        this.pacientes = new ArrayList<>();
        this.citas = new ArrayList<>();
    }

    public void registrarPaciente(Paciente p) {
        pacientes.add(p);
        System.out.println("Paciente registrado: " + p.getNombre());
    }

    public void registrarProfesional(Profesional p) {
        profesionales.add(p);
        System.out.println("Profesional registrado: " + p.getNombre());
    }

    public void registrarAsistente(Asistente a) {
        asistentes.add(a);
        System.out.println("Asistente registrado: " + a.getNombre());
    }

    public void agregarConsultorio(Consultorio c) {
        consultorios.add(c);
        System.out.println("Consultorio agregado: #" + c.getNumero());
    }

    public Consultorio buscarConsultorioDisponible(String fecha, String horario) {
        for (Consultorio c : consultorios) {
            if (c.estaDisponible(fecha, horario)) return c;
        }
        return null;
    }

    public Profesional buscarProfesionalDisponible(String fecha, String horario) {
        for (Profesional p : profesionales) {
            if (p.estaDisponible(fecha, horario)) return p;
        }
        return null;
    }

    public Asistente buscarAsistenteDisponible(String fecha, String horario) {
        for (Asistente a : asistentes) {
            if (a.estaDisponible(fecha, horario)) return a;
        }
        return null;
    }

    // Cita solicitada por el paciente: asignacion automatica
    public Cita agendarCitaPorPaciente(Paciente paciente, String fecha, String horario, Procedimiento procedimiento) {
        System.out.println("\n>> Agendando cita para " + paciente.getNombre() + " el " + fecha + " a las " + horario);

        Consultorio consultorio = buscarConsultorioDisponible(fecha, horario);
        Profesional profesional = buscarProfesionalDisponible(fecha, horario);
        Asistente asistente = buscarAsistenteDisponible(fecha, horario);

        if (consultorio == null) { System.out.println("ERROR: No hay consultorios disponibles."); return null; }
        if (profesional == null) { System.out.println("ERROR: No hay profesionales disponibles."); return null; }
        if (asistente == null)   { System.out.println("ERROR: No hay asistentes disponibles."); return null; }

        return crearCita(fecha, horario, paciente, profesional, asistente, consultorio, procedimiento);
    }

    // Cita agendada por asistente o profesional: asignacion manual
    public Cita agendarCitaManual(Paciente paciente, Profesional profesional, Asistente asistente,
                                   String fecha, String horario, Procedimiento procedimiento) {
        System.out.println("\n>> Agendando cita manual para " + paciente.getNombre() + " el " + fecha + " a las " + horario);

        if (!profesional.estaDisponible(fecha, horario)) {
            System.out.println("ERROR: El profesional " + profesional.getNombre() + " no esta disponible."); return null;
        }
        if (!asistente.estaDisponible(fecha, horario)) {
            System.out.println("ERROR: El asistente " + asistente.getNombre() + " no esta disponible."); return null;
        }
        Consultorio consultorio = buscarConsultorioDisponible(fecha, horario);
        if (consultorio == null) { System.out.println("ERROR: No hay consultorios disponibles."); return null; }

        return crearCita(fecha, horario, paciente, profesional, asistente, consultorio, procedimiento);
    }

    private Cita crearCita(String fecha, String horario, Paciente paciente, Profesional profesional,
                            Asistente asistente, Consultorio consultorio, Procedimiento procedimiento) {
        Cita cita = new Cita(fecha, horario, paciente, profesional, asistente, consultorio, procedimiento);
        consultorio.asignarCita(cita);
        profesional.agregarCita(cita);
        asistente.agregarCita(cita);
        paciente.agregarCita(cita);
        citas.add(cita);
        System.out.println("Cita creada: " + cita.mostrarInfo());
        return cita;
    }

    public void cancelarCita(Cita cita) {
        cita.cancelar();
    }

    public void mostrarTodasLasCitas() {
        System.out.println("\n===== TODAS LAS CITAS DE " + nombre.toUpperCase() + " =====");
        if (citas.isEmpty()) { System.out.println("  Sin citas registradas."); return; }
        for (Cita c : citas) System.out.println("  " + c.mostrarInfo());
    }

    public String getNombre() { return nombre; }
    public ArrayList<Cita> getCitas() { return citas; }
}