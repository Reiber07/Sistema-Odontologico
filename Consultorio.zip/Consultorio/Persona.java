public abstract class Persona {
    private String nombre;
    private String identificacion;
    private String telefono;
    private String email;

    public Persona(String nombre, String identificacion, String telefono, String email) {
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.telefono = telefono;
        this.email = email;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getIdentificacion() { return identificacion; }
    public void setIdentificacion(String identificacion) { this.identificacion = identificacion; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String mostrarInfo() {
        return "[" + getClass().getSimpleName() + "] " + nombre + " (ID: " + identificacion + ")";
    }
}