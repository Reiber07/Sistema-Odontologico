public class Cita {
    private static int contadorId = 1;

    private String id;
    private String fecha;
    private String horario;
    private Paciente paciente;
    private Profesional profesional;
    private Asistente asistente;
    private Consultorio consultorio;
    private Procedimiento procedimiento;
    private boolean cancelada;

    public Cita(String fecha, String horario, Paciente paciente, Profesional profesional,
                Asistente asistente, Consultorio consultorio, Procedimiento procedimiento) {
        this.id = "CITA-" + contadorId++;
        this.fecha = fecha;
        this.horario = horario;
        this.paciente = paciente;
        this.profesional = profesional;
        this.asistente = asistente;
        this.consultorio = consultorio;
        this.procedimiento = procedimiento;
        this.cancelada = false;
    }

    public String getId() { return id; }
    public String getFecha() { return fecha; }
    public String getHorario() { return horario; }
    public Paciente getPaciente() { return paciente; }
    public Profesional getProfesional() { return profesional; }
    public Asistente getAsistente() { return asistente; }
    public Consultorio getConsultorio() { return consultorio; }
    public Procedimiento getProcedimiento() { return procedimiento; }
    public boolean isCancelada() { return cancelada; }

    public void cancelar() {
        this.cancelada = true;
        System.out.println("Cita " + id + " cancelada.");
    }

    public String mostrarInfo() {
        return id + " | " + fecha + " " + horario
                + " | Paciente: " + paciente.getNombre()
                + " | " + profesional.getNombre()
                + " | Asistente: " + asistente.getNombre()
                + " | Consultorio " + consultorio.getNumero()
                + " | Procedimiento: " + procedimiento.getNombre();
    }
}