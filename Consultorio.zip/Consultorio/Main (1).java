public class Main {
    public static void main(String[] args) {

        //  Crear la clinica
        Clinica clinica = new Clinica("Clinica Dental Sonrisa");

        //  Registrar consultorios
        System.out.println("\n--- Registrando consultorios ---");
        Consultorio c1 = new Consultorio(1, "Consultorio de ortodoncia");
        Consultorio c2 = new Consultorio(2, "Consultorio de limpieza");
        clinica.agregarConsultorio(c1);
        clinica.agregarConsultorio(c2);

        //  Registrar profesionales
        System.out.println("\n--- Registrando profesionales ---");
        Profesional dr1 = new Profesional("Dr. Carlos Ruiz", "P001", "3001234567", "carlos@clinica.com", "Ortodoncia");
        Profesional dr2 = new Profesional("Dra. Maria Lopez", "P002", "3109876543", "maria@clinica.com", "Endodoncia");
        clinica.registrarProfesional(dr1);
        clinica.registrarProfesional(dr2);

        //  Registrar asistentes
        System.out.println("\n--- Registrando asistentes ---");
        Asistente a1 = new Asistente("Laura Gomez", "A001", "3201122334", "laura@clinica.com");
        Asistente a2 = new Asistente("Pedro Sanchez", "A002", "3154455667", "pedro@clinica.com");
        a1.setProfesionalAsignado(dr1);
        a2.setProfesionalAsignado(dr2);
        clinica.registrarAsistente(a1);
        clinica.registrarAsistente(a2);

        // Registrar pacientes
        System.out.println("\n--- Registrando pacientes ---");
        Paciente p1 = new Paciente("Ana Torres", "C001", "3006667788", "ana@mail.com");
        Paciente p2 = new Paciente("Luis Martinez", "C002", "3118889900", "luis@mail.com");
        clinica.registrarPaciente(p1);
        clinica.registrarPaciente(p2);

        // Procedimientos
        Procedimiento proc1 = new Procedimiento("Limpieza dental", "Profilaxis completa", 45);
        Procedimiento proc2 = new Procedimiento("Consulta ortodoncia", "Revision de brackets", 30);
        Procedimiento proc3 = new Procedimiento("Extraccion", "Extraccion de molar", 60);

        //  Cita solicitada por el paciente (asignacion automatica)
        System.out.println("\n--- Agendando citas por solicitud del paciente ---");
        Cita cita1 = clinica.agendarCitaPorPaciente(p1, "2026-04-01", "09:00", proc1);
        Cita cita2 = clinica.agendarCitaPorPaciente(p2, "2026-04-01", "09:00", proc2);

        // Intento de cita en horario sin disponibilidad
        System.out.println("\n--- Intentando agendar sin disponibilidad ---");
        clinica.agendarCitaPorPaciente(p1, "2026-04-01", "09:00", proc3);

        // Cita manual agendada por el profesional o asistente
        System.out.println("\n--- Cita agendada manualmente ---");
        Cita cita3 = clinica.agendarCitaManual(p1, dr1, a1, "2026-04-02", "10:00", proc2);

        // Cancelar cita y reagendar el mismo horario
        System.out.println("\n--- Cancelando cita1 y reagendando ---");
        clinica.cancelarCita(cita1);
        Cita cita4 = clinica.agendarCitaPorPaciente(p2, "2026-04-01", "09:00", proc1);

        // Historial por paciente
        System.out.println("\n--- Historial de " + p1.getNombre() + " ---");
        p1.mostrarHistorial();

        System.out.println("\n--- Historial de " + p2.getNombre() + " ---");
        p2.mostrarHistorial();

        // Reporte general
        clinica.mostrarTodasLasCitas();
    }
}