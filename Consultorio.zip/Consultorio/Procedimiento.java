public class Procedimiento {
    private String nombre;
    private String descripcion;
    private int duracionMinutos;

    public Procedimiento(String nombre, String descripcion, int duracionMinutos) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.duracionMinutos = duracionMinutos;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public int getDuracionMinutos() { return duracionMinutos; }
    public void setDuracionMinutos(int duracionMinutos) { this.duracionMinutos = duracionMinutos; }

    public String mostrarInfo() {
        return nombre + " (" + duracionMinutos + " min) - " + descripcion;
    }
}